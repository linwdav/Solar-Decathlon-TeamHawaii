package edu.hawaii.ihale.api;

/**
 * An Object used by HSIM.  Actuators will change this object, and Sensors will
 * read data from it.
 * @author Team Maka
 *
 */
public class Environment {

}
